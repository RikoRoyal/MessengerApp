﻿using System.Collections.Generic;

namespace MessengerApp.Entities
{
    public class User
    {
        public string Id { get; set; } // Изменено на string
        public string Username { get; set; }
        public string Name { get; set; }
        public ICollection<Message> Messages { get; set; }
        public ICollection<ChatUser> ChatUsers { get; set; }
    }
}
