﻿namespace MessengerApp.Repositories
{
    public class Repository
    {
    }
}
