﻿using MessengerApp.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MessengerApp.Interfaces
{
    public interface IChatService
    {
        Task<IEnumerable<Chat>> GetAllChatsAsync();
        Task<Chat> GetChatByIdAsync(int chatId);
        Task AddChatAsync(Chat chat);
        Task<Chat> GetChatByNameAsync(string chatName);
    }
}
