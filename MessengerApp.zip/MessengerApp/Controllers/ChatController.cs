﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using MessengerApp.Interfaces;
using MessengerApp.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using MessengerApp.Entities;

namespace MessengerApp.Controllers
{
    [Route("Chat")]
    public class ChatController : Controller
    {
        private readonly IChatService _chatService;
        private readonly IMessageService _messageService;
        private readonly IUserService _userService;
        private readonly IMapper _mapper;

        public ChatController(IChatService chatService, IMessageService messageService, IUserService userService, IMapper mapper)
        {
            _chatService = chatService;
            _messageService = messageService;
            _userService = userService;
            _mapper = mapper;
        }

        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            var chats = await _chatService.GetAllChatsAsync();
            var chatViewModels = _mapper.Map<IEnumerable<ChatViewModel>>(chats);
            return View(chatViewModels);
        }

        [HttpGet("GetChats")]
        public async Task<IActionResult> GetChats()
        {
            var chats = await _chatService.GetAllChatsAsync();
            var chatViewModels = _mapper.Map<IEnumerable<ChatViewModel>>(chats);
            return Json(chatViewModels);
        }

        [HttpGet("GetChatMessages")]
        public async Task<IActionResult> GetChatMessages(int chatId)
        {
            var messages = await _messageService.GetMessagesByChatId(chatId);
            var messageViewModels = _mapper.Map<IEnumerable<MessageViewModel>>(messages);
            return Json(messageViewModels);
        }

        [HttpPost("CreateMessage")]
        public async Task<IActionResult> CreateMessage(MessageViewModel model, int chatId)
        {
            if (ModelState.IsValid && chatId > 0)
            {
                var message = _mapper.Map<Message>(model);
                message.ChatId = chatId;
                await _messageService.AddMessageAsync(message);
                return RedirectToAction("Index");
            }
            return View(model);
        }

        [HttpGet("SearchUser")]
        public async Task<IActionResult> SearchUser(string username)
        {
            if (string.IsNullOrWhiteSpace(username))
            {
                return Json(new { success = false, message = "Username cannot be empty" });
            }

            var user = await _userService.GetUserByUsernameAsync(username);
            if (user == null)
            {
                return Json(new { success = false, message = "User not found" });
            }
            var userViewModel = new UserViewModel { Username = user.UserName, Id = user.Id };
            return Json(new { success = true, user = userViewModel });
        }
    }
}
