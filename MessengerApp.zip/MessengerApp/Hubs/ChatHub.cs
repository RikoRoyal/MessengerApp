﻿using Microsoft.AspNetCore.SignalR;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using MessengerApp.Interfaces;
using MessengerApp.Entities;

namespace MessengerApp.Hubs
{
    public class ChatHub : Hub
    {
        private static ConcurrentDictionary<string, string> _userConnections = new ConcurrentDictionary<string, string>();
        private readonly IMessageService _messageService;
        private readonly IUserService _userService;

        public ChatHub(IMessageService messageService, IUserService userService)
        {
            _messageService = messageService;
            _userService = userService;
        }

        public override Task OnConnectedAsync()
        {
            var username = Context.User.Identity.Name;
            if (username != null)
            {
                _userConnections[username] = Context.ConnectionId;
            }
            return base.OnConnectedAsync();
        }

        public override Task OnDisconnectedAsync(System.Exception exception)
        {
            var username = Context.User.Identity.Name;
            if (username != null)
            {
                _userConnections.TryRemove(username, out _);
            }
            return base.OnDisconnectedAsync(exception);
        }

        public async Task SendMessage(string fromUser, string toUser, string message, int chatId)
        {
            var sender = await _userService.GetUserByUsernameAsync(fromUser);
            if (sender == null) return;

            var newMessage = new Message
            {
                Text = message,
                Timestamp = DateTime.Now,
                UserId = sender.Id,
                ChatId = chatId
            };

            await _messageService.AddMessageAsync(newMessage);

            if (_userConnections.TryGetValue(toUser, out var recipientConnectionId))
            {
                await Clients.Client(recipientConnectionId).SendAsync("ReceiveMessage", fromUser, message);
            }
            await Clients.Caller.SendAsync("ReceiveMessage", fromUser, message);
        }
    }
}
