﻿using AutoMapper;
using MessengerApp.ViewModels;
using Microsoft.AspNetCore.Identity;

namespace MessengerApp.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<IdentityUser, UserViewModel>()
                .ForMember(dest => dest.Username, opt => opt.MapFrom(src => src.UserName))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Email));
        }
    }
}
