using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MessengerApp.Views.Account
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
