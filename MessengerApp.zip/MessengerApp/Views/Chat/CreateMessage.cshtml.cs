using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MessengerApp.Views.Chat
{
    public class CreateMessageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
